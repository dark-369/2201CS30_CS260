import { asyncHandler } from "../utililties/asyncHandler.util.js";
import { ApiResponse } from "../utililties/ApiResponse.util.js";

const getFinal = asyncHandler(async (req, res) => {
    const user=req.user;
        return res
        .status(200)
        .json(new ApiResponse(
            200,
            {user},
            "User fetched successfully"
        ))
})



export {  getFinal }