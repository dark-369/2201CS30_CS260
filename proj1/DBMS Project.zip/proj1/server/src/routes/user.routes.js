import {Router} from "express";
import { verifyJWT } from "../middlewares/auth.middleware.js";
const router =Router()

//Importing the functions from the service
import { registerUser ,loginUser, logoutUser,  refreshAccessToken, changeCurrentPassword, getCurrentUser, isLoggedIn, Reset_Password, Change_Password} from "../service/user.service.js";


//unsecured routes
router.route("/register").post(registerUser)
router.route("/login").post((loginUser))

//secure routes
router.route("/isloggedin").post(isLoggedIn)
router.route("/current-user").get(verifyJWT, getCurrentUser)
router.route("/logout").post(verifyJWT,logoutUser)
router.route("/refresh-token").post(refreshAccessToken)
router.route("/reset-password-change/:id/:token").post(Change_Password)
router.route("/reset-password").post(Reset_Password)
router.route("/change-password").post(verifyJWT, changeCurrentPassword)

export default router;