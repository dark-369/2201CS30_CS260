import mongoose from "mongoose";
let DB_NAME= process.env.DB_NAME;
let uri= process.env.MONGODB_URI;

const connectDatabase = async () => {
    try {
        const connectionInstance = await mongoose.connect(`${uri}/${DB_NAME}`)
        console.log(`\n MongoDB connected !! DB HOST: ${connectionInstance.connection.host}`);
    } catch (error) {
        console.log("MONGODB connection FAILED ", error);
        throw error;
    }
}

export default connectDatabase