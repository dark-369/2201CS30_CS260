This is the backend part of the project of CS260 at Indian Institute of Technology Patna.
Semester: 4th
Year: 2024

Author:Md Kamran(2201CS47)
       Harsh Dahiya(2201CS30)

Instructions for Running :-
1. Frontend and Backend have to be run separately and simultaneously.Here only backend part has been explained

2. open terminal in directory server

3. type command to build the docker image
        docker build -t kamran676446/dbms:backend .

4. type command to run the docker image
       docker run --name nameofcontainer -p 8000:8000 kamran676446/dbms:backend

In case of Problems :-
1. If connection to MongoDB fails that may be because of the IP address you are using is not listed on the MongoDB account, so please set up your deployment of MongoDB, add your IP address or Select allow all IP address and update the details in .env file.