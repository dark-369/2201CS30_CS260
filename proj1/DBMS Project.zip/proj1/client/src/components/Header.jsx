import React from 'react'

function Header() {
    return (
        <>
            <div className=' bg-white flex flex-col justify-center items-center  p-4'>
            <p class="text-[30px] font-semibold text-amber-950 text-center" >भारतीय प्रौद्योगिकी संस्थान पटना</p>
            <p class="text-[30px] font-semibold text-amber-950 text-center" >Indian Institute of Technology Patna</p>
            </div>

        </>
    )
}

export default Header
