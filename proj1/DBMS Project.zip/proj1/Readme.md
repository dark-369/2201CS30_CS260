This is the DBMS Project Folder

Authors:
    Md Kamran (2201CS47)
    Harsh Dahiya (2201CS30)

The Project is divided into two parts Frontend and Backend in folders client and server respectively.

To run the project use the docker-compose.yml file, by writing in terminal- docker compose up


Alternatively, you can run by
going to folders client and server and follow readme file there to get the project working 