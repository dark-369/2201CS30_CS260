import './App.css'
import Login from './webpages/Login.jsx';
import Signup from './webpages/SignUp.jsx';
import Toast from './webpages/testing.jsx';
import ResetPassword from './webpages/ResetPassword.jsx'
import ResetPasswordchange from './webpages/Change_Password.jsx'
import Form1 from './webpages/Form_1.jsx';
import Form2 from './webpages/Form_2.jsx';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { useEffect, useState } from 'react';
import axios from 'axios';
import Form3 from './webpages/Form_3.jsx';
import Form6 from './webpages/Form_6.jsx';
import Form5 from './webpages/Form_5.jsx';
import Form4 from './webpages/Form_4.jsx';
import Form7 from './webpages/Form_7.jsx';
import Form8 from './webpages/Form_8.jsx';
import Changepassword from './webpages/Changepassword.jsx';
import FinalDeclaration from './webpages/FinalDeclaration.jsx';
import PDF from './webpages/PDF.jsx';


function App() {

  return (
    <>
      <BrowserRouter>
      <Routes>
        <Route path="/" element={<Login/>}/>
        <Route path="register" element={<Signup/>}/>
        <Route path="/form1" element={<Form1/>}/>
        <Route path="toast" element={<Toast/>}/>
        <Route path="resetpassword" element={<ResetPassword/>}/>
        <Route path="reset-password/:id/:token" element={<ResetPasswordchange/>}/>
        <Route path="change-password" element={<Changepassword/>}/>
        <Route path="/form2" element={<Form2/>}/>
        <Route path="/form3" element={<Form3/>}/>
        <Route path="/form6" element={<Form6/>}/>
        <Route path="/form5" element={<Form5/>}/>
        <Route path="/form4" element={<Form4/>}/>
        <Route path="/form7" element={<Form7/>}/>
        <Route path="/form8" element={<Form8/>}/>
        <Route path="/finaldeclaration" element={<FinalDeclaration/>}/>
        <Route path="/pdf" element={<PDF/>}/>

      </Routes>
      </BrowserRouter>
    </>
  )
}

export default App
