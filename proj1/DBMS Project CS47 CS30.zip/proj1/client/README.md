This is the frontend part of the project of CS260 at Indian Institute of Technology Patna.
Semester: 4th
Year: 2024

Author:Md Kamran(2201CS47)
       Harsh Dahiya(2201CS30)

Instructions for Running 
1. Frontend and Backend have to be run separately and simultaneously.Here only frontend part has been explained

2. open terminal in directory client

3. type command to build the docker image
        docker build -t kamran676446/dbms:frontend .

4. type command to run the docker image
       docker run --name nameofcontainer2 -p 5173:5173 kamran676446/dbms:frontend